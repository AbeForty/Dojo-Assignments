import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
// Implement OnInit.
export class AppComponent implements OnInit {
  title = 'Restful Tasks API';
  constructor(private _httpService: HttpService) { }
  // ngOnInit will run when the component is initialized, after the constructor method.
  newTask: any;
  editTask: any;
  editing:boolean;
  tasks:any;
  ngOnInit() {
    this.getTasksFromService();
    this.newTask = { title: "", description: "" };
    this.tasks=[];
  }
  // tasks = [];
  getTasksFromService() {
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log("Got our tasks!", data)
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.tasks = data['data'];
    });
  }
  addTasksToService(newTask) {
    console.log("this works");
    let obs = this._httpService.addTask(newTask);
    obs.subscribe(data => {
      console.log("Got our tasks!", data);
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.getTasksFromService();
      this.tasks = data['data'];
    });
  }
  getSingleTask(id){
    let obs = this._httpService.getSingleTask(id);
    obs.subscribe(data => {
     this.editing = true;
     this.editTask = data['data'];
    //  console.log(id);
    });
  }
  componentEditTask(){
    console.log("Hello")
    let obs = this._httpService.editTask(this.editTask);
    obs.subscribe(data=>{
      console.log(data);      
      this.getTasksFromService();
      this.editTask = { title: "", description: "" }
      this.editing = false;
    })    
  }
  deleteSingleTask(id){
    let obs = this._httpService.deleteSingleTask(id);
    obs.subscribe(data => {
    this.getTasksFromService();
    });
  }
  onSubmit() {
    // Code to send off the form data (this.newTask) to the Service
    // ...
    // Reset this.newTask to a new, clean object.
    this.addTasksToService(this.newTask)
    console.log("Working")
    this.newTask = { title: "", description: "" };
  }
}
