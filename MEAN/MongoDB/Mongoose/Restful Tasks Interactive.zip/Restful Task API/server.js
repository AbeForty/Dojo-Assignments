var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/restful_tasks');
// Create a Schema for Users
var TasksSchema = new mongoose.Schema({
    title: {type:String},
    description: {type:String, default: ""},
    completed: {type: Boolean, default: false},
}, { timestamps: true })

// Store the Schema under the name 'User'
mongoose.model('Task', TasksSchema);

// Retrieve the Schema called 'User' and store it to the variable User
var Task = mongoose.model('Task');

// require express
var express = require("express");
// path module -- try to figure out where and why we use this
var path = require("path");
// create the express app
var app = express();
var bodyParser = require('body-parser');

// use it!
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static( __dirname + '/HelloAngular/dist' ));
// Retrieve all Tasks
// Retrieve a Task by ID
// Create a Task
// Update a Task by ID
// Delete a Task by ID
app.get('/tasks', function (req, res) {
    Task.find({},function (err, tasks) {
        if(err){
             // respond with JSON
            res.json({error: err})
         }
         else {
             // respond with JSON
            res.json({data: tasks})
         }
    });
});
app.get('/task', function (req, res) {
    var id = request.body.id
    Task.find({_id:id},function (err, tasks) {
        if(err){
             // respond with JSON
            res.json({message: "Error", error: err})
         }
         else {
             // respond with JSON
            res.json({message: "Success", data: tasks})
         }
    });
});
app.put('/new', function (req, res) {
    // console.log("POST DATA \n\n", req.body);
    var taskInstance = new Task()
    taskInstance.name = req.body.name
    taskInstance.save(function (err) {
        if (err) {
            res.json({message: "Error", error: err})
        }
        else {
            res.json({message: "Success", data: taskInstance})
        }

    })
});
app.delete('/remove', function (req, res) {
    var id = req.body.id;    
    Task.remove({_id: id}, function(err){
        if (err) return console.error(err);
        res.json({message: "Success", data: task})
    });
});
app.listen(8000, function () {
    console.log("listening on port 8000");
});
