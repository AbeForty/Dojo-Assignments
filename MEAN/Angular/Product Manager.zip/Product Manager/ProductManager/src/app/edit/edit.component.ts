import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(private _route: ActivatedRoute,
    private _router: Router, private _httpService: HttpService) { }
  Products: any
  editProduct: any;
  id:any;

  ngOnInit() {
    // this.getProductsFromService();
 
    this.Products = [];
    this._route.params.subscribe((params: Params) => {
      // this.id = params['id']
      this.getSingleProduct(params['id']);
    });
    this.editProduct= [];

  }
  updateProductToService(editProduct) {
    let obs = this._httpService.editProduct(editProduct);
    obs.subscribe(data => {
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      // this.getProductsFromService();
      this.Products = data['data'];
    });
  }
  getSingleProduct(id){
    let obs = this._httpService.getSingleProduct(id);
    obs.subscribe(data => {
    this.editProduct = data['data'];
    });
  }
  saveProduct() {
    this.updateProductToService(this.editProduct);
  }
}
