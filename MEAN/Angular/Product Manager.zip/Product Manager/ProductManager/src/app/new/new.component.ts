import { Component, OnInit } from '@angular/core';
import {HttpService} from '../http.service';
@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  constructor(private _httpService: HttpService) { }
  Products:any
  newProduct: any;

  ngOnInit() {
    this.getProductsFromService();
    this.newProduct = { name: "", price: "", imageurl: "" };
    this.Products=[];
  }
  addProductToService(newProduct) {
    let obs = this._httpService.addProduct(newProduct);
    obs.subscribe(data => {
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.getProductsFromService();
      this.Products = data['data'];
    });
  }
  getProductsFromService(){
    let observable = this._httpService.getProducts();
    observable.subscribe(data => {
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.Products = data['data'];
    });
  }
  saveProduct() {
    // console.log(randomNumber);
    // console.log(this.newGold)  
    this.addProductToService(this.newProduct);
    this.getProductsFromService();
    this.newProduct = { name: "", price: "", imageurl:"" }
    // console.log(`Click event is working with event: `, event);
  }
  // onButtonClick(): void { 
  //   this.deleteGoldsToService();
  // }
}

