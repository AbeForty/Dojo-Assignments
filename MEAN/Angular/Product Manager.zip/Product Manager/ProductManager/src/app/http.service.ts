import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class HttpService {

  constructor(private _http: HttpClient) {
    this.getProducts();
  }
  getProducts() {
    // Remove the lines of code where we make the variable 'tempObservable' and subscribe to it.
    // tempObservable = this._http.get('/Products');
    // tempObservable.subscribe(data => console.log("Got our Products!", data));
    // Return the observable to wherever the getProducts method was invoked.
    return this._http.get('/api/Products');
  }
  addProduct(newProduct) {
    window.location.href = "/products";
    return this._http.post('/api/product', newProduct)
  }
  editProduct(editProduct) {
    window.location.href = "/products";
    return this._http.put('/api/product/'+ editProduct._id, editProduct)
  }
  getSingleProduct(id){
    return this._http.get('/api/product/' + id)
  }
  deleteSingleProduct(id){
    return this._http.delete('/api/product/'+id);
  }
}
