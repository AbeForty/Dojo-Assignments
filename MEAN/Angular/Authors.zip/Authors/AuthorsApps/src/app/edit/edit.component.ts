import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(private _route: ActivatedRoute,
    private _router: Router, private _httpService: HttpService) { }
  authors: any
  editAuthor: any;
  id:any;

  ngOnInit() {
    // this.getAuthorsFromService();
 
    this.authors = [];
    this._route.params.subscribe((params: Params) => {
      // this.id = params['id']
      this.getSingleAuthor(params['id']);
    });
    this.editAuthor= [];

  }
  updateAuthorToService(editAuthor) {
    let obs = this._httpService.editAuthor(editAuthor);
    obs.subscribe(data => {
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      // this.getAuthorsFromService();
      this.authors = data['data'];
    });
  }
  getSingleAuthor(id){
    let obs = this._httpService.getSingleAuthor(id);
    obs.subscribe(data => {
    this.editAuthor = data['data'];
    });
  }
  saveAuthor() {
    this.updateAuthorToService(this.editAuthor);
  }

}
