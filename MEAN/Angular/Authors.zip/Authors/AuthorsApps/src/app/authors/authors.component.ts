import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-authors',
  templateUrl: './authors.component.html',
  styleUrls: ['./authors.component.css']
})
export class AuthorsComponent implements OnInit {
  title = 'Favorite authors';
  constructor(private _httpService: HttpService) { 
    // this.getAuthorsFromService();
  }
  // ngOnInit will run when the component is initialized, after the constructor method.
  newAuthor: any;
  editAuthor: any;
  editing:boolean;
  Authors:any;
  ngOnInit() {
    this.getAuthorsFromService();
    this.newAuthor = { name: "" };
    this.Authors=[];
  }
  getAuthorsFromService() {
    let observable = this._httpService.getAuthors();
    observable.subscribe(data => {
      // In this example, the array of Authors is assigned to the key 'Authors' in the data object. 
      // This may be different for you, depending on how you set up your Author API.
      this.Authors = data['data'];
    });
  }
  addAuthorsToService(newAuthor) {
    let obs = this._httpService.addAuthor(newAuthor);
    obs.subscribe(data => {
      // In this example, the array of Authors is assigned to the key 'Authors' in the data object. 
      // This may be different for you, depending on how you set up your Author API.
      this.getAuthorsFromService();
      this.Authors = data['data'];
    });
  }
  getSingleAuthor(id){
    let obs = this._httpService.getSingleAuthor(id);
    obs.subscribe(data => {
     this.editing = true;
     this.editAuthor = data['data'];
    });
  }
  componentEditAuthor(){
    let obs = this._httpService.editAuthor(this.editAuthor);
    obs.subscribe(data=>{
      this.getAuthorsFromService();
      this.editAuthor = { name: ""}
      this.editing = false;
    })    
  }
  deleteSingleAuthor(id){
    let obs = this._httpService.deleteSingleAuthor(id);
    obs.subscribe(data => {
      this.getAuthorsFromService();
    });
  }
  onSubmit() {
    // Code to send off the form data (this.newAuthor) to the Service
    // ...
    // Reset this.newAuthor to a new, clean object.
    this.addAuthorsToService(this.newAuthor)
    this.newAuthor = { name: ""};
  }
}
