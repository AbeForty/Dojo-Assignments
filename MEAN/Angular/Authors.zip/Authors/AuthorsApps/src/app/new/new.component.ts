import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {

  constructor(private _httpService: HttpService) { }
  authors:any
  newAuthor: any;

  ngOnInit() {
    this.getAuthorsFromService();
    this.newAuthor = { name: "" };
    this.authors=[];
  }
  addAuthorToService(newAuthor) {
    console.log("this works");
    let obs = this._httpService.addAuthor(newAuthor);
    obs.subscribe(data => {
      console.log("Got our authors!", data);
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.getAuthorsFromService();
      this.authors = data['data'];
    });
  }
  getAuthorsFromService(){
    let observable = this._httpService.getAuthors();
    observable.subscribe(data => {
      console.log("Got our authors!", data)
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.authors = data['data'];
      console.log(this.authors)
    });
  }
  saveAuthor() {
    console.log("Hello")
    // console.log(randomNumber);
    // console.log(this.newGold)  
    this.addAuthorToService(this.newAuthor);
    this.getAuthorsFromService();
    this.newAuthor = { name: ""}
    // console.log(`Click event is working with event: `, event);
  }
  // onButtonClick(): void { 
  //   this.deleteGoldsToService();
  // }
}
