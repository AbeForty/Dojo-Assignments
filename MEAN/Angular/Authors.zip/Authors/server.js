// Retrieve the Schema called 'User' and store it to the variable User
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/authors');
// Create a Schema for Users
var AuthorSchema = new mongoose.Schema({
    name: { type: String, required: true, minlength:3},
}, { timestamps: true })
// Store the Schema under the name 'User'
mongoose.model('Authors', AuthorSchema);
// Retrieve the Schema called 'User' and store it to the variable User
var Author = mongoose.model('Authors');
// require express
var express = require("express");
// path module -- try to figure out where and why we use this
var path = require("path");
// create the express app
var app = express();
var bodyParser = require('body-parser');

// use it!
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static( __dirname + '/AuthorsApps/dist' ));
// Retrieve all Tasks
// Retrieve a Task by ID
// Create a Task
// Update a Task by ID
// Delete a Task by ID

app.get('/api/authors', function (req, res) {
    Author.find({},function (err, authors) {
        if(err){
             // respond with JSON
            console.log(err);
            res.json({error: err});
         }
         else {
             // respond with JSON
            console.log(authors);
            res.json({data: authors});
         }
    });
});
app.post('/api/author', function (req, res) {
    console.log("Body: " + req.body);
    // console.log("POST DATA \n\n", req.body);
    // var golds = req.params.golds;
    // var randomNumber = Math.floor(Math.random()*(max-min+1)+min);
    var authorInstance = new Author();
    authorInstance.name = req.body.name;
    authorInstance.save(function (err, savedAuthor) {
        if (err) {
            console.log(err);
            res.json({message: "Error", error: err})
        }
        else {
            console.log(savedAuthor);
            res.json({message: "Success", data: savedAuthor})
        }

    })
});
app.get('/api/author/:id', function (req, res) {
    Author.findOne({_id: req.params.id},function (err, authors) {
        if(err){
             // respond with JSON
            console.log(err);
            res.json({error: err});
         }
         else {
             // respond with JSON
            console.log(authors);
            res.json({data: authors});
         }
    });
});
app.put('/api/author/:id', function (req, res) {
    console.log(req.params.id)
    console.log(req.body)
    Author.findByIdAndUpdate(req.params.id,req.body, (err,confirmation)=>{
        if(err){
            console.log(err);
            res.json({error: err})
        }else{
            console.log("Hi")
            res.json({success: 'hhehehehehehe'})
        }
    })
});
app.delete('/api/author/:id', function (req, res) {
    Author.remove({_id:req.params.id}, (err,confirmation)=>{
        if(err){
            console.log(err);
        }else{
            console.log("Hi")
            res.json({success: 'hhehehehehehe'})
        }
    })
});
app.all("*", (req,res,next) => {
    res.sendFile(path.resolve("./AuthorsApps/dist/index.html"))
});  
app.listen(8000, function () {
    console.log("listening on port 8000");
});
