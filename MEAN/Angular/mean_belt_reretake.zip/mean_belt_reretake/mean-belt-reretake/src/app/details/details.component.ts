import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {


  constructor(private _route: ActivatedRoute,
    private _router: Router, private _httpService: HttpService) { }
  pets: any
  singlePet: any;
  id:any;

  ngOnInit() {
    // this.getAuthorsFromService();
 
    this.pets = [];
    this._route.params.subscribe((params: Params) => {
      // this.id = params['id']
      this.getSinglePet(params['id']);
    });
    this.singlePet= [];
  }
  getSinglePet(id){
    let obs = this._httpService.getSinglePet(id);
    obs.subscribe(data => {
        this.singlePet = data['data'];
    });
  }
  deleteSinglePet(id){
    let obs = this._httpService.deleteSinglePet(id);
    obs.subscribe(data => {
        this._router.navigate(['/pets']);
    });
  }
  likeSinglePet(id){
    let obs = this._httpService.postUpVote(id);
    obs.subscribe(data => {
      this.getSinglePet(id);
      document.getElementById("like").setAttribute("disabled", "disabled");
        // this._router.navigate(['/pets']);
    });
  }

}
