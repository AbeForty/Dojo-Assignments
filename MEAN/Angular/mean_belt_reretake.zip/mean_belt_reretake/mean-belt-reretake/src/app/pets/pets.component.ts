import { Component, OnInit } from '@angular/core';
import { HttpService} from '../http.service';

@Component({
  selector: 'app-pets',
  templateUrl: './pets.component.html',
  styleUrls: ['./pets.component.css']
})
export class PetsComponent implements OnInit {

  constructor(private _httpService: HttpService) { 
    // this.getAuthorsFromService();
  }
  // ngOnInit will run when the component is initialized, after the constructor method.
  newPet: any;
  editPet: any;
  pets:any;
  ngOnInit() {
    this.getPetsFromService();
    this.pets=[];
  }
  getPetsFromService() {
    let observable = this._httpService.getPets();
    observable.subscribe(data => {
      // In this example, the array of Authors is assigned to the key 'Authors' in the data object. 
      // This may be different for you, depending on how you set up your Author API.
      this.pets = data['data'];
    });
  }
  getSinglePet(id){
    let obs = this._httpService.getSinglePet(id);
    obs.subscribe(data => {
     this.editPet = data['data'];
    });
  }

}
