import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {


  constructor(private _route: ActivatedRoute,
    private _router: Router, private _httpService: HttpService) { }
  pets: any
  editPet: any;
  id:any;
  errors:string[];
  formErrors:string[];

  ngOnInit() {
    // this.getAuthorsFromService();
 
    this.pets = [];
    this._route.params.subscribe((params: Params) => {
      // this.id = params['id']
      this.getSinglePet(params['id']);
    });
    this.editPet = [];
    // document.getElementById("submit").setAttribute("disabled", "disabled");

  }
  validateInput(){
    this.formErrors =[];
    if (this.editPet.name == ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Pet must contain a name");
    }
    if (this.editPet.name.length < 3 && this.editPet.name != ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Name must be at least three characters long.");
    }
    if (this.editPet.type == ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Pet must contain a type");
    }
    if (this.editPet.type.length < 3 && this.editPet.type != ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Type must be at least three characters long.");
    }
    if (this.editPet.description == ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Pet must contain a description");
    }
    if (this.editPet.description.length < 3 && this.editPet.description != ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Description must be at least three characters long.");
    }
    if(this.formErrors.length == 0){
      this.formErrors =[];
      document.getElementById("submit").removeAttribute("disabled");
    }
  }
  updatePetToService(editPet) {
    console.log(editPet);
    let obs = this._httpService.editPet(editPet);
    obs.subscribe((data:any) => {
      this.errors = [];
      console.log(data);
      if (data.error) {
        // for (var key in data.error) {
        //   console.log(key);
          this.errors.push(data.error['message']);
        // }
      } else {
        this._router.navigate(['/details/'+ editPet._id]);
      }
      this.pets = data['data'];
    });
  }
  getSinglePet(id){
    let obs = this._httpService.getSinglePet(id);
    obs.subscribe(data => {
        this.editPet = data['data'];
    });
  }
  savePet() {
    this.updatePetToService(this.editPet);
  }
}

