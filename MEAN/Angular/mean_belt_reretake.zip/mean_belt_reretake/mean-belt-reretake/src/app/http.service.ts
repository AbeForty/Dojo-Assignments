import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class HttpService {
  constructor(private _http: HttpClient) { 
    this.getPets();
  }
  getPets() {
    // Remove the lines of code where we make the variable 'tempObservable' and subscribe to it.
    // tempObservable = this._http.get('/Authors');
    // tempObservable.subscribe(data => console.log("Got our Authors!", data));
    // Return the observable to wherever the getAuthors method was invoked.
    return this._http.get('/api/pets');
  }
  addPet(newPet) {
    return this._http.post('/api/pet', newPet)
  }
  editPet(editPet) {
    console.log("Hello")
    return this._http.put('/api/pet/'+ editPet._id, editPet)
  }
  postUpVote(id){
    return this._http.put('/api/pets/like/'+ id, id)
  }
  getSinglePet(id){
    return this._http.get('/api/pet/' + id)
  }
  getSinglePetName(name){
    return this._http.get('/api/pet/name/' + name)
  }
  deleteSinglePet(id){
    return this._http.delete('/api/pet/' + id)
  }
}
