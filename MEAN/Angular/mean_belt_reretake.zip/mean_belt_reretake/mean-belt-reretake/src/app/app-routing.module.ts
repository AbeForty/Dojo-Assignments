import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewComponent } from './new/new.component';
import { EditComponent } from './edit/edit.component';
import { PetsComponent } from './pets/pets.component';
import { DetailsComponent } from './details/details.component';

const routes: Routes = [  
{ path: 'pets', component: PetsComponent },
{ path: 'new', component: NewComponent },
{ path: 'edit/:id', component: EditComponent },
{ path: 'details/:id', component: DetailsComponent },
{ path: '', pathMatch: 'full', redirectTo: '/pets' },

]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
