import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
    constructor(private _route: ActivatedRoute,
      private _router: Router,private _httpService: HttpService) { }
  
      pets:any
      // skill1:any;
      // skill2:any;
      // skill3:any;
      newPet: any;
      errors:string[];
      formErrors: string[];
      disabledValue:string
      containsPet: any;

      ngOnInit() {
        this.getPetsFromService();
        this.newPet = { name: "", type:"", description:"", skills: [{},{},{}]};
        // this.skill1 = {skill: ""};
        // this.skill2 = {skill: ""};
        // this.skill3 = {skill: ""}
        this.pets=[];
        this.formErrors=[];
        document.getElementById("submit").setAttribute("disabled", "disabled");
      }
      addPetToService(newPet) {
        console.log("this works");
        let obs = this._httpService.addPet(newPet);
        obs.subscribe((data:any) => {
          // console.log("Got our authors!", data);
          this.errors = [];
          if (data.error) {
            // for (var key in data.error) {
            //   console.log(key);
              this.errors.push(data.error['message']);
            // }
          } else {
            this._router.navigate(['/pets']);
          }
          this.getPetsFromService();
          this.pets = data['data'];
        });
      }
      getPetsFromService(){
        let observable = this._httpService.getPets();
        observable.subscribe(data => {
          console.log("Got our authors!", data)
          // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
          // This may be different for you, depending on how you set up your Task API.
          this.pets = data['data'];
          console.log(this.pets)
        });
      }
    validateInput(){
      this.formErrors =[];
      if (this.newPet.name == ""){
        document.getElementById("submit").setAttribute("disabled", "disabled");
        this.formErrors.push("Pet must contain a name");
      }
      if (this.newPet.name.length < 3 && this.newPet.name != ""){
        document.getElementById("submit").setAttribute("disabled", "disabled");
        this.formErrors.push("Name must be at least three characters long.");
      }
      // if(this.newPet.name.length > 3){
      //   this.getSinglePetName(this.newPet.name);
      //   console.log(this.containsPet);
      // }
      if (this.newPet.type == ""){
        document.getElementById("submit").setAttribute("disabled", "disabled");
        this.formErrors.push("Pet must contain a type");
      }
      if (this.newPet.type.length < 3 && this.newPet.type != ""){
        document.getElementById("submit").setAttribute("disabled", "disabled");
        this.formErrors.push("Type must be at least three characters long.");
      }
      if (this.newPet.description == ""){
        document.getElementById("submit").setAttribute("disabled", "disabled");
        this.formErrors.push("Pet must contain a description");
      }
      if (this.newPet.description.length < 3 && this.newPet.description != ""){
        document.getElementById("submit").setAttribute("disabled", "disabled");
        this.formErrors.push("Description must be at least three characters long.");
      }
      if(this.formErrors.length == 0){
        this.formErrors =[];
        document.getElementById("submit").removeAttribute("disabled");
      }
    }
    // getSinglePetName(name){
    //   console.log("Hello")
    //   let obs = this._httpService.getSinglePetName(name);
    //   obs.subscribe(data => {
    //       this.containsPet = data['data'];
    //   });
    // }
      savePet() {
        console.log("Hello")
        this.addPetToService(this.newPet);
        this.getPetsFromService();
        this.newPet = { name: "", type:"", description:"", skills: [{},{},{}]};
      }
  
  }
