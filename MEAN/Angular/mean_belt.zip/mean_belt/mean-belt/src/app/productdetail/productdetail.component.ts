import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-productdetail',
  templateUrl: './productdetail.component.html',
  styleUrls: ['./productdetail.component.css']
})
export class ProductdetailComponent implements OnInit {


  constructor(private _route: ActivatedRoute,
    private _router: Router, private _httpService: HttpService) { }
  products: any
  singleProduct: any;
  id:any;

  ngOnInit() {
    // this.getAuthorsFromService();
 
    this.products = [];
    this._route.params.subscribe((params: Params) => {
      // this.id = params['id']
      this.getSingleProduct(params['id']);
    });
    this.singleProduct= [];
    document.getElementById("submit").setAttribute("disabled", "disabled");
    document.getElementById("delete").setAttribute("disabled", "disabled");
  }
  getSingleProduct(id){
    let obs = this._httpService.getSingleProduct(id);
    obs.subscribe(data => {
        this.singleProduct = data['data'];
        if (this.singleProduct['quantity'] == 0){
          document.getElementById("delete").removeAttribute("disabled");
        }
    });
  }
    deleteSingleProduct(id){
    let obs = this._httpService.deleteSingleProduct(id);
    obs.subscribe(data => {
        this._router.navigate(['/products']);
    });
  }
}
