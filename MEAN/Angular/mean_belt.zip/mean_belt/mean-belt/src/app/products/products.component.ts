import { Component, OnInit } from '@angular/core';
import { HttpService} from '../http.service';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private _httpService: HttpService) { 
    // this.getAuthorsFromService();
  }
  // ngOnInit will run when the component is initialized, after the constructor method.
  newProduct: any;
  editProduct: any;
  products:any;
  ngOnInit() {
    this.getProductsFromService();
    this.products=[];
  }
  getProductsFromService() {
    let observable = this._httpService.getProducts();
    observable.subscribe(data => {
      // In this example, the array of Authors is assigned to the key 'Authors' in the data object. 
      // This may be different for you, depending on how you set up your Author API.
      this.products = data['data'];
    });
  }
  getSingleProduct(id){
    let obs = this._httpService.getSingleProduct(id);
    obs.subscribe(data => {
     this.editProduct = data['data'];
    });
  }


}
