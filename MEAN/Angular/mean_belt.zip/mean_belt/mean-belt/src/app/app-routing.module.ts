import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductsComponent } from './products/products.component';
import { ProductnewComponent } from './productnew/productnew.component';
import { ProductupdateComponent } from './productupdate/productupdate.component';
import { ProductdetailComponent } from './productdetail/productdetail.component';

const routes: Routes = [  
{ path: 'products', component: ProductsComponent },
{ path: 'products/new', component: ProductnewComponent },
{ path: 'products/edit/:id', component: ProductupdateComponent },
{ path: 'products/:id', component: ProductdetailComponent },
{ path: '', pathMatch: 'full', redirectTo: '/products' },

]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
