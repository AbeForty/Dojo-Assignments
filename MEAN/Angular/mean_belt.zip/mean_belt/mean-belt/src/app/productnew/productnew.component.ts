import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-productnew',
  templateUrl: './productnew.component.html',
  styleUrls: ['./productnew.component.css']
})
export class ProductnewComponent implements OnInit {

  constructor(private _route: ActivatedRoute,
    private _router: Router,private _httpService: HttpService) { }

    products:any
    newProduct: any;
    errors:string[];
    formErrors: string[];
    disabledValue:string
    ngOnInit() {
      this.getProductsFromService();
      this.newProduct = { name: "", quantity: "", price:"" };
      this.products=[];
      this.formErrors=[];
      document.getElementById("submit").setAttribute("disabled", "disabled");
    }
    addProductToService(newAuthor) {
      console.log("this works");
      let obs = this._httpService.addProduct(newAuthor);
      obs.subscribe((data:any) => {
        // console.log("Got our authors!", data);
        this.errors = [];
        if (data.error) {
          // for (var key in data.error) {
          //   console.log(key);
            this.errors.push(data.error['message']);
          // }
        } else {
          this._router.navigate(['/products']);
        }
        this.getProductsFromService();
        this.products = data['data'];
      });
    }
    getProductsFromService(){
      let observable = this._httpService.getProducts();
      observable.subscribe(data => {
        console.log("Got our authors!", data)
        // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
        // This may be different for you, depending on how you set up your Task API.
        this.products = data['data'];
        console.log(this.products)
      });
    }
  validateInput(){
    this.formErrors =[];
    if (this.newProduct.name == ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Product must contain a name");
    }
    if (this.newProduct.name.length < 3 && this.newProduct.name != ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Name must be at least three characters long.");
    }
    if (Number(this.newProduct.quantity) < 0 && this.newProduct.quantity != ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Quantity must be a number greater than or equal to 0.");
    }
    if (this.newProduct.quantity == ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Product must contain a quantity");
    }
    if (Number(this.newProduct.price) < 0 && this.newProduct.price != ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Price must be a number greater than equal to 0.");
    }
    if (this.newProduct.price == ""){
      document.getElementById("submit").setAttribute("disabled", "disabled");
      this.formErrors.push("Product must contain a price");
    }
    if(this.formErrors.length == 0){
      this.formErrors =[];
      document.getElementById("submit").removeAttribute("disabled");
    }
  }
    saveProduct() {
      console.log("Hello")
      this.addProductToService(this.newProduct);
      this.getProductsFromService();
      this.newProduct = { name: "", quantity:"", price:""}
    }

}
