import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class HttpService {

  constructor(private _http: HttpClient) { 
    this.getProducts();
  }
  getProducts() {
    // Remove the lines of code where we make the variable 'tempObservable' and subscribe to it.
    // tempObservable = this._http.get('/Authors');
    // tempObservable.subscribe(data => console.log("Got our Authors!", data));
    // Return the observable to wherever the getAuthors method was invoked.
    return this._http.get('/api/products');
  }
  addProduct(newProduct) {
    return this._http.post('/api/product', newProduct)
  }
  editProduct(editProduct) {
    return this._http.put('/api/product/'+ editProduct._id, editProduct)
  }
  getSingleProduct(id){
    return this._http.get('/api/product/' + id)
  }
  deleteSingleProduct(id){
    return this._http.delete('/api/product/'+id)
  }
}
