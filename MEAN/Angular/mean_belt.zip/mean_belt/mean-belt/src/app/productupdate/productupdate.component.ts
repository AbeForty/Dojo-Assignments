import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-productupdate',
  templateUrl: './productupdate.component.html',
  styleUrls: ['./productupdate.component.css']
})
export class ProductupdateComponent implements OnInit {


  constructor(private _route: ActivatedRoute,
    private _router: Router, private _httpService: HttpService) { }
  products: any
  editProduct: any;
  id:any;
  errors:string[];
  formErrors:string[];

  ngOnInit() {
    // this.getAuthorsFromService();
 
    this.products = [];
    this._route.params.subscribe((params: Params) => {
      // this.id = params['id']
      this.getSingleProduct(params['id']);
    });
    this.editProduct= [];
    // document.getElementById("submit").setAttribute("disabled", "disabled");

  }
//   validateInput(){
//     this.formErrors =[];
//     if (this.editProduct.name == ""){
//       document.getElementById("submit").setAttribute("disabled", "disabled");
//       this.formErrors.push("Product must contain a name");
//     }
//     if (this.editProduct.name.length < 3){
//       document.getElementById("submit").setAttribute("disabled", "disabled");
//       this.formErrors.push("Name must be at least three characters long.");
//     }
//     if (Number(this.editProduct.quantity) < 0 && this.editProduct.quantity != ""){
//       document.getElementById("submit").setAttribute("disabled", "disabled");
//       this.formErrors.push("Quantity must be a number greater than or equal to 0.");
//     }
//     if (this.editProduct.quantity == ""){
//       document.getElementById("submit").setAttribute("disabled", "disabled");
//       this.formErrors.push("Product must contain a quantity");
//     }
//     if (Number(this.editProduct.price) < 0 && this.editProduct.price != ""){
//       document.getElementById("submit").setAttribute("disabled", "disabled");
//       this.formErrors.push("Price must be a number greater than equal to 0.");
//     }
//     if (this.editProduct.price == ""){
//       document.getElementById("submit").setAttribute("disabled", "disabled");
//       this.formErrors.push("Product must contain a price");
//     }
//     if(this.formErrors.length == 0){
//       this.formErrors =[];
//       document.getElementById("submit").removeAttribute("disabled");
//     }
// }
  updateAuthorToService(editProduct) {
    let obs = this._httpService.editProduct(editProduct);
    obs.subscribe((data:any) => {
      this.errors = [];
      console.log(data);
      if (data.error) {
        // for (var key in data.error) {
        //   console.log(key);
          this.errors.push(data.error['message']);
        // }
      } else {
        this._router.navigate(['/products']);
      }
      this.products = data['data'];
    });
  }
  getSingleProduct(id){
    let obs = this._httpService.getSingleProduct(id);
    obs.subscribe(data => {
        this.editProduct = data['data'];
    });
  }
  saveProduct() {
    this.updateAuthorToService(this.editProduct);
  }
}
