import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {

  constructor(private _route: ActivatedRoute,
    private _router: Router,private _httpService: HttpService) { }
  authors:any
  newAuthor: any;
  errors:string[];
  disabledValue:string
  ngOnInit() {
    this.getAuthorsFromService();
    this.newAuthor = { name: "" };
    this.authors=[];
    document.getElementById("submit").setAttribute("disabled", "disabled");
  }
  addAuthorToService(newAuthor) {
    console.log("this works");
    let obs = this._httpService.addAuthor(newAuthor);
    obs.subscribe((data:any) => {
      // console.log("Got our authors!", data);
      this.errors = [];
      if (data.error) {
        // for (var key in data.error) {
        //   console.log(key);
          this.errors.push(data.error['message']);
        // }
      } else {
        this._router.navigate(['/authors']);
      }
      this.getAuthorsFromService();
      this.authors = data['data'];
    });
  }
  getAuthorsFromService(){
    let observable = this._httpService.getAuthors();
    observable.subscribe(data => {
      console.log("Got our authors!", data)
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.authors = data['data'];
      console.log(this.authors)
    });
  }
  // validateInput($event){
  // 
  // }
validateInput(){
    console.log(this.newAuthor.name.length);
    console.log(this.newAuthor.name);
    if (this.newAuthor.name.length < 2){
      document.getElementById("submit").setAttribute("disabled", "disabled");
    }
    else{
      document.getElementById("submit").removeAttribute("disabled");
    }
}
  saveAuthor() {
    console.log("Hello")
    // console.log(randomNumber);
    // console.log(this.newGold)  
    this.addAuthorToService(this.newAuthor);
    this.getAuthorsFromService();
    this.newAuthor = { name: ""}
    // console.log(`Click event is working with event: `, event);
  }
  // onButtonClick(): void { 
  //   this.deleteGoldsToService();
  // }
}
