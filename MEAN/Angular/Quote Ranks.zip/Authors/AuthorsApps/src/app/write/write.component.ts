import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-new',
  templateUrl: './write.component.html',
  styleUrls: ['./write.component.css']
})
export class WriteComponent implements OnInit {

  constructor(private _route: ActivatedRoute,
    private _router: Router, private _httpService: HttpService) { }
  author:any;
  quotes:any;
  newQuote:any;
  editAuthor: any;
  id: any = 0;
  errors:string[];
  ngOnInit() {
    this.editAuthor = { name: "" };
    this.newQuote = {quote: "", votes: 0}
    this.author=[];
    this._route.params.subscribe((params: Params) => {
        this.id = (params['id']);
    });
    this.getQuotesFromService();
    document.getElementById("submit").setAttribute("disabled", "disabled");
  }
  validateInput(){
    if (this.newQuote.quote.length < 2){
      document.getElementById("submit").setAttribute("disabled", "disabled");
    }
    else{
      document.getElementById("submit").removeAttribute("disabled");
    }
}
  addQuoteToService(newQuote) {
    let obs = this._httpService.addQuote(newQuote, this.id);
    obs.subscribe((data:any) => {
      console.log("Got our Quotes!", data);
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.errors = [];
      console.log(data.error)
      if (data.error) {
        // for (var key in data.error) {
        //   console.log(key);
          this.errors.push(data.error['message']);
        // }
      } else {
        // this._router.navigate(['/authors']);
      }
      this.getQuotesFromService();
      this.quotes = data['data'];
    });
  }
  getQuotesFromService(){
    let observable = this._httpService.getSingleAuthor(this.id);
    observable.subscribe(data => {        
      console.log("Got our Quotes!", data)
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.author = data['data'];
      console.log(this.author)
    });
  }
  saveQuote() {
    console.log(this.newQuote);
    // console.log(randomNumber);
    // console.log(this.newGold)  
    this.addQuoteToService(this.newQuote);
    this._router.navigate(['/quotes/', this.id])
    // this.getQuotesFromService();
    // this.editAuthor = { name: ""}
    // console.log(`Click event is working with event: `, event);
  }
  // onButtonClick(): void { 
  //   this.deleteGoldsToService();
  // }
  updateAuthorToService(editAuthor) {
    let obs = this._httpService.editAuthor(editAuthor);
    obs.subscribe(data => {
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      // this.getQuotesFromService();
      this.author = data['data'];
    });
  }
  getSingleAuthor(id){
    let obs = this._httpService.getSingleAuthor(id);
    obs.subscribe(data => {
    this.editAuthor = data['data'];
    });
  }
}
