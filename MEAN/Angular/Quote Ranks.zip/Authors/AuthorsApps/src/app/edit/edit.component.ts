import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  constructor(private _route: ActivatedRoute,
    private _router: Router, private _httpService: HttpService) { }
  authors: any
  editAuthor: any;
  id:any;
  errors:string[];

  ngOnInit() {
    // this.getAuthorsFromService();
 
    this.authors = [];
    this._route.params.subscribe((params: Params) => {
      // this.id = params['id']
      this.getSingleAuthor(params['id']);
    });
    this.editAuthor= [];
    document.getElementById("submit").setAttribute("disabled", "disabled");

  }
  validateInput(){
    if (this.editAuthor.name.length < 2){
      document.getElementById("submit").setAttribute("disabled", "disabled");
    }
    else{
      document.getElementById("submit").removeAttribute("disabled");
    }
}
  updateAuthorToService(editAuthor) {
    let obs = this._httpService.editAuthor(editAuthor);
    obs.subscribe((data:any) => {
      this.errors = [];
      console.log(data);
      if (data.error) {
        // for (var key in data.error) {
        //   console.log(key);
          this.errors.push(data.error['message']);
        // }
      } else {
        this._router.navigate(['/authors']);
      }
      this.authors = data['data'];
    });
  }
  getSingleAuthor(id){
    let obs = this._httpService.getSingleAuthor(id);
    obs.subscribe(data => {
        this.editAuthor = data['data'];
    });
  }
  saveAuthor() {
    this.updateAuthorToService(this.editAuthor);
  }

}
