import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class HttpService {

  constructor(private _http: HttpClient) {
    this.getAuthors();
  }
  getAuthors() {
    // Remove the lines of code where we make the variable 'tempObservable' and subscribe to it.
    // tempObservable = this._http.get('/Authors');
    // tempObservable.subscribe(data => console.log("Got our Authors!", data));
    // Return the observable to wherever the getAuthors method was invoked.
    return this._http.get('/api/authors');
  }
  addAuthor(newAuthor) {
    return this._http.post('/api/author', newAuthor)
  }
  addQuote(newQuote, author_id) {
    return this._http.post('/api/quote/'+ author_id, newQuote)
  }
  editAuthor(editAuthor) {
    return this._http.put('/api/author/'+ editAuthor._id, editAuthor)
  }
  getSingleAuthor(id){
    return this._http.get('/api/author/' + id)
  }
  deleteSingleAuthor(id){
    return this._http.delete('/api/author/'+id)
  }
  deleteSingleQuote(authorId, quoteId){
    // console.log(authorId);
    // console.log(quoteId);
    console.log('/api/authors/'+ authorId +'/' + quoteId)
    return this._http.delete('/api/authors/'+ authorId +'/' + quoteId)
  }

  postUpVote(authorId, quoteId){
    return this._http.post('/api/authors/'+ authorId +'/quotes/' + quoteId, {vote: "up"})
  }

  postDownVote(authorId, quoteId){
    return this._http.post('/api/authors/' + authorId + '/quotes/' + quoteId, { vote: "down" })
  }
}

