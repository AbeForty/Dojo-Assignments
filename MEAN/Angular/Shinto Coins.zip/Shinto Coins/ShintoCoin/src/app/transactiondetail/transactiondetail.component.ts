import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-transactiondetail',
  templateUrl: './transactiondetail.component.html',
  styleUrls: ['./transactiondetail.component.css']
})
export class TransactiondetailComponent implements OnInit {
  transactions:any;
  constructor(
    private _route: ActivatedRoute,
    private _router: Router, 
    private _httpService: HttpService)
  {
    this.transactions =[];
  }
 id = 0;
  ngOnInit() {
    this._route.params.subscribe((params: Params) => {
      // this.id = params['id']
      this.transactions = this._httpService.getTransactions(params['id']);
    });
  }


}
