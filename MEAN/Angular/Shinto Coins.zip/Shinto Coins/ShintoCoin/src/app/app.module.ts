import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; // <-- import FormsModule.
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { MinecoinsComponent } from './minecoins/minecoins.component';
import { BuycoinsComponent } from './buycoins/buycoins.component';
import { SellcoinsComponent } from './sellcoins/sellcoins.component';
import { LedgerComponent } from './ledger/ledger.component';
import { HttpService } from './http.service';
import { TransactiondetailComponent } from './transactiondetail/transactiondetail.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MinecoinsComponent,
    BuycoinsComponent,
    SellcoinsComponent,
    LedgerComponent,
    TransactiondetailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
