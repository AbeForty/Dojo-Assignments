import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-minecoins',
  templateUrl: './minecoins.component.html',
  styleUrls: ['./minecoins.component.css']
})
export class MinecoinsComponent implements OnInit {

  constructor(private _httpService: HttpService) { }

  ngOnInit() {
  }
  result:any;
  amount = this._httpService.getCoinAmount();
  value = 1;
  updateValue(){
    if (this.result == 13){
      this._httpService.incrementID();
      this._httpService.addToTransaction({id:this._httpService.getLastID(), action:"Mine", value:1, amount:this._httpService.value})
      this._httpService.addToAmount(1);
      this._httpService.addValue(1);
    }
  }
}
