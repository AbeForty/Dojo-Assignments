import { HomeComponent } from './home/home.component';
import { BuycoinsComponent } from './buycoins/buycoins.component';
import { SellcoinsComponent } from './sellcoins/sellcoins.component';
import { MinecoinsComponent } from './minecoins/minecoins.component';
import { LedgerComponent } from './ledger/ledger.component';
// import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TransactiondetailComponent } from './transactiondetail/transactiondetail.component';

const routes: Routes = [
  { path: 'home',component: HomeComponent },
  { path: 'buy',component: BuycoinsComponent },
  { path: 'sell',component: SellcoinsComponent },
  { path: 'mine',component: MinecoinsComponent },
  { path: 'ledger',component: LedgerComponent },
  { path: 'transactions/:id',component: TransactiondetailComponent },
  // use a colon and parameter name to include a parameter in the url
  // { path: 'gamma/:id', component: GammaComponent },
  { path: '', pathMatch: 'full', redirectTo: '/home' },
  // { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
