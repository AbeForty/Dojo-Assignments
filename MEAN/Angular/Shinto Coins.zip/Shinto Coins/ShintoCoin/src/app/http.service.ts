import { Injectable, transition } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class HttpService {

  constructor(private _http: HttpClient) { }
  last_id = 0;
  value: Number = 1;
  transactions = [];
  coinAmount = 0;
  shareTransactions() {
    return this.transactions;
  }
  getLastID(){
    return this.last_id
  }
  getCoinAmount(){
    return this.coinAmount
  }
  addValue(num){
    this.value += num;
  }
  addToAmount(num){    
    this.coinAmount = this.coinAmount + num;
  }
  incrementID(){
    this.last_id += 1;
  }
  addToTransaction(transaction) {
    this.transactions.push(transaction);
  }
  getTransactions(id){
    for(let i =0; i < this.transactions.length; i++){
      if(this.transactions[i].id == id){
        return this.transactions[i];
      }
    }
  }
}
