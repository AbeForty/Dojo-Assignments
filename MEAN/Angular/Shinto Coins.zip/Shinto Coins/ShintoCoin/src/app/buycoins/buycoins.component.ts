import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-buycoins',
  templateUrl: './buycoins.component.html',
  styleUrls: ['./buycoins.component.css']
})
export class BuycoinsComponent implements OnInit {

  constructor(private _httpService: HttpService) { }

  ngOnInit() {
  }
  amount = this._httpService.getCoinAmount();
  value = this._httpService.value;
  enteredValue: Number
  updateValue() {
    if (this.enteredValue > 1){
      this._httpService.incrementID();
      this._httpService.addToTransaction({ id: this._httpService.last_id, action: "Buy", value: this.enteredValue, amount:this._httpService.value})
      this._httpService.addToAmount(Number(this.enteredValue));
      this._httpService.addValue(1);
      this.amount = this._httpService.getCoinAmount();
      this.value = this._httpService.value;
    }
  }
}
