import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
// Implement OnInit.
export class AppComponent implements OnInit {
  title = 'Ninja Gold';
  newGold: any;
  constructor(private _httpService: HttpService) { }
  // ngOnInit will run when the component is initialized, after the constructor method.
  ngOnInit() {
    this.getGoldsFromService();
  }
  golds = 0;
  descriptions = [];
  getGoldsFromService() {
    let observable = this._httpService.getGold();
    observable.subscribe(data => {
      console.log("Got our golds!", data)
      var myGolds = 0;
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      data['data'].forEach(golds => {
        myGolds += golds.golds;
      });
      this.golds = myGolds;
      this.descriptions = data['data'];
      console.log(this.descriptions);
    });
  }
  putGoldsToService(Gold) {
    var obs = this._httpService.addGold(Gold);
    obs.subscribe(data => console.log(data))
  }
  // deleteGoldsToService() {
  //   var obs2 = this._httpService.deleteGold();
  //   obs2.subscribe(data => console.log(data))
  // }
  onButtonClickParams(max: number, min: number, location:string): void {
    var randomNumber = Math.floor(Math.random() * (max - min + 1) + min);
    var description = ""
    if (randomNumber > 0){
      description = "You earned " + randomNumber + " from the " + location
    }
    else{
      description = "You lost " + randomNumber*-1 + " from the " + location      
    }
    // console.log(randomNumber);
    this.newGold = { gold: randomNumber, description: description }
    // console.log(this.newGold)  
    this.putGoldsToService(this.newGold);
    this.getGoldsFromService();
    // console.log(`Click event is working with event: `, event);
  }
  // onButtonClick(): void { 
  //   this.deleteGoldsToService();
  // }
}
