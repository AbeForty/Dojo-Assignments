import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class HttpService {

  constructor(private _http: HttpClient){
    this.getGold();
  }
  getGold(){
    // // our http response is an Observable, store it in a variable
    // let bulbasaur = this._http.get('https://pokeapi.co/api/v2/pokemon/1/');
    // // subscribe to the Observable and provide the code we would like to do with our data from the response
    // bulbasaur.subscribe(data => console.log("Bulbasaur's Abilities are: ", data["abilities"][0]["ability"]["name"], "and", data["abilities"][1]["ability"]["name"]));
    // let overgrow = this._http.get('https://pokeapi.co/api/v2/ability/65/');
    // // subscribe to the Observable and provide the code we would like to do with our data from the response
    // overgrow.subscribe(data => console.log("There are", data["pokemon"].length, "Pokemon with this ability!"));
    return this._http.get('/golds');

  }
  addGold(newGold){
    // // our http response is an Observable, store it in a variable
    // let bulbasaur = this._http.get('https://pokeapi.co/api/v2/pokemon/1/');
    // // subscribe to the Observable and provide the code we would like to do with our data from the response
    // bulbasaur.subscribe(data => console.log("Bulbasaur's Abilities are: ", data["abilities"][0]["ability"]["name"], "and", data["abilities"][1]["ability"]["name"]));
    // let overgrow = this._http.get('https://pokeapi.co/api/v2/ability/65/');
    // // subscribe to the Observable and provide the code we would like to do with our data from the response
    // overgrow.subscribe(data => console.log("There are", data["pokemon"].length, "Pokemon with this ability!"));
    return this._http.post('/gold', newGold);

  }
  // delete(){
  //   // // our http response is an Observable, store it in a variable
  //   // let bulbasaur = this._http.get('https://pokeapi.co/api/v2/pokemon/1/');
  //   // // subscribe to the Observable and provide the code we would like to do with our data from the response
  //   // bulbasaur.subscribe(data => console.log("Bulbasaur's Abilities are: ", data["abilities"][0]["ability"]["name"], "and", data["abilities"][1]["ability"]["name"]));
  //   // let overgrow = this._http.get('https://pokeapi.co/api/v2/ability/65/');
  //   // // subscribe to the Observable and provide the code we would like to do with our data from the response
  //   // overgrow.subscribe(data => console.log("There are", data["pokemon"].length, "Pokemon with this ability!"));
  //   return this._http.post('/delete');

  // }
 
}
