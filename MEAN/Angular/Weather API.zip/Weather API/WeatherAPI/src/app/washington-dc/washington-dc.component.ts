import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-washington-dc',
  templateUrl: './washington-dc.component.html',
  styleUrls: ['./washington-dc.component.css']
})
export class WashingtonDcComponent implements OnInit {

  constructor(private _httpService: HttpService) {
    this.getWeatherFromService();
  }
  weather: any;
  ngOnInit() {
    this.weather = [];
  }
  getWeatherFromService() {
    let observable = this._httpService.getWeatherWashingtonDC();
    observable.subscribe(data => {
      console.log(data);
      this.weather = data;
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
    });
  }
}
