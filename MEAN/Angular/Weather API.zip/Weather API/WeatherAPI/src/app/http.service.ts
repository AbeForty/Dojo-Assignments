import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class HttpService {

  constructor(private _http: HttpClient) {
    // this.getWeather();
   }
  getWeatherBurbank(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=burbank,us&&appid=75ae9e5e0fdf89d119a88f2ba1fdfccb');
  }
  getWeatherSanJose(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=san%20josé,us&&appid=75ae9e5e0fdf89d119a88f2ba1fdfccb');
  }  
  getWeatherSeattle(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=seattle,us&&appid=75ae9e5e0fdf89d119a88f2ba1fdfccb');
  }
  getWeatherChicago(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=chicago,us&&appid=75ae9e5e0fdf89d119a88f2ba1fdfccb');
  }
  getWeatherDallas(){
    return this._http.get('http://api.openweathermap.org/data/2.5/weather?q=dallas,us&&appid=75ae9e5e0fdf89d119a88f2ba1fdfccb');
  }
  getWeatherWashingtonDC(){
    return this._http.get('  http://api.openweathermap.org/data/2.5/weather?q=Washington%20DC.,us&&appid=75ae9e5e0fdf89d119a88f2ba1fdfccb');
  }
}
