import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-chicago',
  templateUrl: './chicago.component.html',
  styleUrls: ['./chicago.component.css']
})
export class ChicagoComponent implements OnInit {

  constructor(private _httpService: HttpService) {
    this.getWeatherFromService();
  }
  weather: any;
  ngOnInit() {
    this.weather = [];
  }
  getWeatherFromService() {
    let observable = this._httpService.getWeatherChicago();
    observable.subscribe(data => {
      console.log(data);
      this.weather = data;
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
    });
  }
}
