import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-seattle',
  templateUrl: './seattle.component.html',
  styleUrls: ['./seattle.component.css']
})
export class SeattleComponent implements OnInit {

  constructor(private _httpService: HttpService) {
    this.getWeatherFromService();
  }
  weather: any;
  ngOnInit() {
    this.weather = [];
  }
  getWeatherFromService() {
    let observable = this._httpService.getWeatherSeattle();
    observable.subscribe(data => {
      console.log(data);
      this.weather = data;
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
    });
  }
}
