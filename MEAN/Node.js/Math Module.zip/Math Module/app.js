var mathlib = require('./mathlib')();
// var test = mathlib();
mathlib.add(5,6);
mathlib.multiply(5,6);
mathlib.square(15);
mathlib.random(3,15)