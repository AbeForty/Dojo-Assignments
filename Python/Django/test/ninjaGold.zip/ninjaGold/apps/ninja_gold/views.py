# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect
from time import localtime, strftime
import random
def index(request):
    returnMessage = ""
    if not 'coins' in request.session:
        request.session['coins'] = 0
    if not 'message' in request.session:
        request.session['message'] = []
    else:
        for i in request.session['message']:
            returnMessage += i + "\n"
    context = {
         "coins": request.session['coins'],
         "message": returnMessage
    }
    return render(request, "index.html",context)
def process_money(request):
    if request.method == "POST":
        if request.POST['building'] == "farm":
            random_coins  = random.randrange(10, 21)        
        elif request.POST['building'] == "house":
            random_coins  = random.randrange(5, 11)
        elif request.POST['building'] == "cave":
            random_coins  = random.randrange(2, 6)
        elif request.POST['building'] == "casino":
            random_coins  = random.randrange(0, 50)
            lose_or_win = random.randrange(0,2)
        if request.POST['building'] != "casino":
            message_to_send = "Earned " + str(random_coins) + " golds from the " + request.POST['building']  + "!" + " (" + strftime("%Y/%m/%d %H:%M %p", localtime())+")"
            message_log = request.session['message']
            message_log.append(message_to_send)
            request.session['message'] = message_log
            request.session['coins'] += random_coins
        else:
            if lose_or_win == 0:
                request.session['coins'] += random_coins
                message_to_send = "Entered a casino and won " + str(random_coins) + " golds! Lucky you!" + " (" + strftime("%Y/%m/%d %H:%M %p", localtime()) +")"
                message_log = request.session['message']
                message_log.append(message_to_send)
                request.session['message'] = message_log
            elif lose_or_win == 1 and random_coins != 0:
                request.session['coins'] -= random_coins
                message_to_send = "Entered a casino and lost " + str(random_coins) + " golds... Ouch..." + " (" + strftime("%Y/%m/%d %H:%M %p", localtime()) +")"
                message_log = request.session['message']
                message_log.append(message_to_send)
                request.session['message'] = message_log
            elif lose_or_win == 1 and random_coins == 0:
                request.session['coins'] -= random_coins
                message_to_send = "Entered a casino and lost " + str(random_coins) + " golds... Lucky you!" + " (" + strftime("%Y/%m/%d %H:%M %p", localtime()) +")"
                message_log = request.session['message']
                message_log.append(message_to_send)
                request.session['message'] = message_log
    return redirect('/')
def reset(request):
    request.session.flush()
    return redirect('/')
# Create your views here.
