# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from models import *
import re
import bcrypt
from time import localtime, strptime
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
# PASSWORD_REGEX = re.compile(r'^(?=.*\d).{8,}$')
# Create your views here.
def index(request):
    if not 'id' in request.session:
        return render(request, 'pythonbelt_retake/index.html')
    else:
        return redirect('/dashboard')
def dashboard(request):
    if not 'id' in request.session:
        return redirect ("/")
    else:
        your_gift_list = []
        gift_list = []
        gift_name_list = []
        if len(Gift.objects.all()) > 0:
            for i in range(int(Gift.objects.first().id), int(Gift.objects.last().id)+1):
                if len(Gift.objects.filter(id = i)) > 0:
                    if not Gift.objects.get(id = i).name in gift_name_list and len(Gift.objects.filter(id = i, adder = Users.objects.get(id = request.session['id']))) < 1 and len(Gift.objects.get(id = i).users.filter(username = Users.objects.get(id = request.session['id']).username)) == 0:
                        gift_name_list.append(Gift.objects.get(id = i).name)
                        gift_list.append(Gift.objects.get(id = i))
                try:
                    if Gift.objects.get(id = i).adder == Users.objects.get(id = request.session['id']) or len(Gift.objects.get(id = i).users.filter(username = Users.objects.get(id = request.session['id']).username)) > 0: 
                        your_gift_list.append(Gift.objects.get(id = i))
                except:
                    continue             
            context = {
                'id': request.session['id'],
                'name':  Users.objects.get(id=request.session['id']).username,
                'gifts': gift_list,
                'your_gifts': your_gift_list
            }
            return render(request, 'pythonbelt_retake/gifts.html', context)
        else:
            context = {
                'id': request.session['id'],
                'name':  Users.objects.get(id=request.session['id']).username,
            }
            return render(request, 'pythonbelt_retake/gifts.html', context)
def show_gift_add(request):
    if not 'id' in request.session:
        return redirect('/')
    else:
        return render(request, 'pythonbelt_retake/GiftsAdd.html')
def add(request):
    if not 'id' in request.session:
        return redirect('/')
    else:
        if request.method == "POST":
            error = False
            if len(request.POST['item']) < 3:
                messages.error(request, "Please enter an item/product name that is 3 or more characters long.")
                error = True
            if error:
                return redirect('/wish_items/create')
            else:
                Gift.objects.create(name = request.POST['item'], adder = Users.objects.get(id = request.session['id']))
                return redirect('/dashboard')
def add_to_wishlist(request, number):
    if not 'id' in request.session:
        return redirect('/')
    else:
        if request.method == "POST":          
            my_gift = Gift.objects.get(id = number)
            my_gift.users.add(Users.objects.get(id = request.session['id']))
            return redirect('/dashboard')
def item_show(request, number):   
    if not 'id' in request.session: 
       return redirect("/")
    else:
        usersList = []
        my_gift = Gift.objects.get(id = number)
        for user in my_gift.users.all():
            if not user.name in usersList:
                usersList.append(user.username)
        usersList.append(my_gift.adder.username)
        context = {
            "gift": my_gift,
            "users": usersList
        }
        return render(request, 'pythonbelt_retake/item.html', context)
def delete(request, number):
    if not 'id' in request.session:
        return redirect('/')
    else:
        if request.method == "POST":               
            Gift.objects.get(id=number).delete()              
            return redirect('/dashboard')
def remove(request, number):
    if not 'id' in request.session:
        return redirect('/')
    else:
        if request.method == "POST":                     
            my_user = Users.objects.get(id=request.session['id'])
            my_gift_object = Gift.objects.get(id=number)
            my_gift_object.users.remove(my_user)            
            return redirect('/dashboard')
def register(request):
    if request.method == "POST":
        error = False
        nameWithoutSpaces = request.POST['name'].replace(" ", "")
        if len(request.POST['name']) < 3: 
            messages.error(request, "Name must be longer than 2 characters.")
            error = True
        if not nameWithoutSpaces.isalpha():
            messages.error(request, "Name must only be alphabetical characters.")
            error = True
        if len(request.POST['username']) < 3:
            messages.error(request, "Username must be longer than 2 characters.")
            error = True
        if len(Users.objects.filter(username = request.POST['username'])) > 0 :
            messages.error(request, "Username is already taken.")
            error = True       
        if len(request.POST['password']) < 8:
            messages.error(request, "Password is too short.")
            error = True
        if request.POST['password'] != request.POST['confirm_password']:
            messages.error(request, "Passwords do not match.")
            error = True
        try:
            date_hired = strptime(request.POST['date_hired'],"%Y-%m-%d")
        except:
            messages.error(request, "Date is invalid.")
            error = True
        if error:
            return redirect('/')
        else:
            hashedpw = bcrypt.hashpw(request.POST['password'].encode(),bcrypt.gensalt())
            user = Users.objects.create(name = request.POST['name'], username = request.POST['username'], password = hashedpw, hired_date = request.POST['date_hired'])
            request.session['id'] = user.id
    return redirect('/dashboard')
def login(request):
    if request.method == "POST":
        the_user_list = Users.objects.filter(username = request.POST['username'])
        if len(the_user_list) > 0:
            the_user = the_user_list[0]
        else:
            messages.error(request, "Email or Password incorrect")
            return redirect('/')
        if bcrypt.checkpw(request.POST['password'].encode(), the_user.password.encode()):
            request.session['id'] = the_user.id
            return redirect('/dashboard')
        else:
            return redirect('/')
    return redirect('/')
def logout(request):
    request.session.flush()
    return redirect('/')