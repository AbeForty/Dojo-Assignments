from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^main$', views.index),
    url(r'^$', views.index),
    url(r'^dashboard$', views.dashboard),
    url(r'^wish_items/create$', views.show_gift_add),
    url(r'^wish_items/add$', views.add),
    url(r'^wish_items/add_to_wishlist/(?P<number>\d+)$', views.add_to_wishlist),
    url(r'^wish_items/remove/(?P<number>\d+)$', views.remove),
    url(r'^wish_items/delete/(?P<number>\d+)$', views.delete),
    url(r'^wish_items/(?P<number>\d+)$', views.item_show),
    url(r'^register$', views.register),
    url(r'^login$', views.login),
    url(r'^logout$', views.logout),
]
