class DojosController < ApplicationController
  def index
    @dojo = Dojo.all
    @num_of_dojos = Dojo.count
    render 'index'
  end
  def new
    render 'new'
  end
  def create    
    my_user = Dojo.create(dojo_params)
    if my_user.errors.full_messages != []
      flash[:error] = my_user.errors.full_messages
      redirect_to '/dojos/new'
    else
      redirect_to '/dojos'
    end
  end
  def show
    @currentDojo = Dojo.find(params[:id])
    @students = Student.where(dojo: @currentDojo)
    render 'show'
  end
  def update
    my_user = Dojo.update(params[:id], dojo_params)
    if my_user.errors.full_messages != []
      flash[:error] = my_user.errors.full_messages
      redirect_to '/dojos/' + params[:id] + '/edit'
    else
      redirect_to '/dojos'
    end
  end
  def destroy
    Dojo.find(params[:id]).destroy()
    redirect_to '/dojos'
  end
  def edit
    @currentDojo = Dojo.find(params[:id])
    render 'edit'
  end
  private
  def dojo_params
    params.require(:dojos).permit(:branch, :street, :city, :state)
  end
end
