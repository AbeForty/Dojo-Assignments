class StudentsController < ApplicationController
    def new
        @dojoList = Dojo.all().select(:branch)
        @currentDojo = params[:dojo_id]
        @currentDojoName = Dojo.find(params[:dojo_id]).branch
        render 'new'
    end
    def create    
        my_user = Student.create(first_name: student_params[:first_name], last_name: student_params[:last_name], email: student_params[:email], dojo:Dojo.find(params[:dojo_id]))
        if my_user.errors.full_messages != []
            flash[:error] = my_user.errors.full_messages
            redirect_to '/dojos/'+ params[:dojo_id].to_s + '/students/new'
        else
            redirect_to '/dojos/' + params[:dojo_id].to_s
        end
    end
    def show
        @currentStudent = Student.find(params[:id])
        @currentDojo =  Dojo.find(params[:dojo_id])
        @date = @currentStudent.created_at
        @students = Student.all().where(dojo: @currentDojo).where(created_at: @date.midnight..@date.end_of_day).where.not(id: @currentStudent.id)
        @currentDojoName = Dojo.find(params[:dojo_id]).branch
        render 'show'
    end
    def update
        my_user = Student.update(params[:id], student_params)
        if my_user.errors.full_messages != []
            flash[:error] = my_user.errors.full_messages
            redirect_to '/dojos/' + params[:dojo_id].to_s + '/students/' + params[:id].to_s + '/edit'
        else
            redirect_to '/dojos/' + params[:dojo_id].to_s + '/students/' + params[:id].to_s
        end
    end
    def destroy
        Student.find(params[:id]).destroy()
        redirect_to '/dojos'
    end
    def edit
        @dojoList = Dojo.all().select(:branch)
        @currentDojoName = Dojo.find(params[:dojo_id]).branch
        @currentDojo = Dojo.find(params[:dojo_id])
        @currentStudent = Student.find(params[:id])
        render 'edit'
    end
    private
    def student_params
        params.require(:students).permit(:first_name, :last_name, :email)
    end
end
