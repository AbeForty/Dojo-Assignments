class SurveyController < ApplicationController
  def process_data
    session[:name] = params[:name]
    session[:location] = params[:location]
    session[:language] = params[:language]
    session[:comment] = params[:comment]
    
    redirect_to '/survey/results'
  end
  def results
    @name = session[:name]
    @location = session[:location]
    @language = session[:language]
    @comment = session[:comment]
    flash[:success] = "Thanks for submitting this form! You have submitted this form " + session[:times].to_s + " times now."
    render 'results'
  end
  def main
    if !session[:times]
      session[:times] = 0
    else
      session[:times] += 1
    end 
    render 'main'
  end
  private
    def survey_params
      params.require(:survey).permit(:name, :location, :language, :comment)
    end
end
