class DojosController < ApplicationController
  def index
    @dojo = Dojo.all
    @num_of_dojos = Dojo.count
    render 'index'
  end
end
