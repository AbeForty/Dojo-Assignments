class TimesController < ApplicationController
  def main
    @date = DateTime.now.strftime("%b %d %Y")
    @time = DateTime.now.strftime("%I:%M %p")
  end
end
