class RpgController < ApplicationController
  def farm
    gold = rand(10..20)
    session[:gold]+= gold
    session[:log].insert(0,"You found " + gold.to_s + " from the house")
    redirect_to '/rpg'
  end

  def cave
    gold = rand(5..10)
    session[:gold]+= gold
    session[:log].insert(0,"You found " + gold.to_s + " from the cave")    
    redirect_to '/rpg'
  end

  def casino
    gold = rand(-50..50)
    session[:gold]+= gold
    if gold < 0
      session[:log].insert(0,"You lost " + (gold * -1).to_s + " from the casino")
    else
      session[:log].insert(0,"You won " + gold.to_s + " from the casino")
    end
    redirect_to '/rpg'
  end

  def house    
    gold = rand(2..5)
    session[:gold]+= gold
    session[:log].insert(0,"You found " + gold.to_s + " from the house")
    redirect_to '/rpg'
  end
  def reset
    session[:gold] = 0
    session[:log] = []
    redirect_to '/rpg'
  end
  def rpg
    if !session[:gold]
      session[:gold] = 0
    end
    if !session[:log]
      session[:log] = []
    end
  end
end
