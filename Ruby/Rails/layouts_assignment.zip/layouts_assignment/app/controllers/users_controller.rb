class UsersController < ApplicationController
  def index
    @user = User.all
    render layout: 'two_column'
  end
  def create
    User.create(user_params)
    redirect_to '/users/index'
  end
  private
  def user_params
      params.require(:users).permit(:first_name, :last_name, :favorite_language)
  end
end
