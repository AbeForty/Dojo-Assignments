class PostsController < ApplicationController
  def index
    @post = Post.joins(:user).all
    @author = User.all
    render layout: 'three_column'
  end
  def create
    Post.create(title: post_params[:title], content: post_params[:content], user: User.find(post_params[:author]))
    redirect_to '/posts'
  end
  private
  def post_params
      params.require(:posts).permit(:title, :content, :author)
  end
end
