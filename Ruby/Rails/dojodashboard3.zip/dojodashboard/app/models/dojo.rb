class Dojo < ActiveRecord::Base
    ADDRESS_REGEX = /\d{1,5}\s\w?.?\s?(\b\w*\b\s){1,2}\w*\.?/i
    validates :branch, :city, presence: true
    validates :street, presence: true, format: { with: ADDRESS_REGEX }
    validates :state, presence: true, length: { maximum: 2 } 
end
