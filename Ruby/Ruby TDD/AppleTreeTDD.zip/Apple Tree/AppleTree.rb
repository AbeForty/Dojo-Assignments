class AppleTree
    attr_accessor :age
    attr_reader :description, :count, :height
    def initialize
        @age = 0
        @height = 1
        @count = 0
    end
    def year_gone_by
        @age += 1
        @height = @height + @height * 0.10
        if @age > 3 && @age < 10
            @count += 2
        end
    end
    def pick_apples
        @count = 0
    end
end
# myTree = AppleTree.new
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# myTree.year_gone_by
# puts "Age: " + myTree.age.to_s
# puts "Height: " + myTree.height.to_s
# puts "Count: " + myTree.count.to_s
