require_relative 'AppleTree' # include our Project class in our spec file
RSpec.describe "Grow a tree" do
    before(:each) do 
        @tree = AppleTree.new
    end    
    context "Ages less than 3" do
        before(:each) do 
            @tree.year_gone_by
        end
        it "grows after a year" do        
            expect(@tree.height).to eq(1.10)
            expect(@tree.age).to eq(1)
            expect(@tree.count).to eq(0)
        end
    end
    context "Ages 3 to 7" do
        before(:each) do 
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
        end     
        it "grows for 5 years" do
            expect(@tree.height).to eq(1.61051)
            expect(@tree.age).to eq(5)
            expect(@tree.count).to eq(4)        
        end
    end
    context "Ages greater than 10" do
        before(:each) do 
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
            @tree.year_gone_by
        end     
        it "grows for 5 years" do
            expect(@tree.height).to eq(4.177248169415652)
            expect(@tree.age).to eq(15)
            expect(@tree.count).to eq(12)        
        end
    end
end