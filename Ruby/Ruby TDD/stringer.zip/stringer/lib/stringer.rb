require "stringer/version"
module Stringer
    def self.spacify *strings
        string = ""
        strings.each do |s|
          if string != ""
            string += " " + s
          else
            string += s
          end
        end
        string
    end
    def self.minify (str, max_length)      
      str = str[0...max_length] + "..."
    end 
    def self.replacify(input, original, replace)    
      input.gsub! original, replace
    end
    def self.tokenize(input)
        arr = []
        input.split(' ').each { |c| 
          arr.push(c)
      }
    end
    def self.removify(input, original)    
      input.gsub! (original) + " ", ""
    end            
  end
