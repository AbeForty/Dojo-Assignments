class Project
    def initialize(name, description, owner, tasks) 
        @project_name = name 
        @project_description = description 
        @owner = owner
        @tasks = tasks
        puts "Created project #{@project_name}"
      end
    def name 
      @project_name
    end
    def name= (project_name)
      @project_name = project_name
    end
    def tasks
      @tasks
    end
    def add_tasks(task)
      @tasks.push(task)
    end
    def elevator_pitch
        @pitch = @project_name +  ", " + @project_description
    end
end
  # project1 = Project.new("Project 1", "Description 1")
  # puts project1.name # => "Project 1"
  # puts project1.elevator_pitch  # => "Project 1, Description 1"