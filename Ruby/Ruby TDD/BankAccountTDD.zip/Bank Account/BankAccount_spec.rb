require_relative 'bankaccount'
RSpec.describe BankAccount do
    before(:each) do 
        @account1 = BankAccount.new
        @account2 = BankAccount.new
        @account1.deposit(500, "checking") 
        @account1.deposit(1500, "savings")
      end
    it 'has a getter for checking balance' do
        expect(@account1.checking_balance).to eq(500)
    end 
    it 'has a getter for total balance' do
        expect(@account1.show_total).to eq(2000) 
    end 
    it 'has a getter for total balance' do
        expect(@account1.withdraw(300, "checking")).to eq(200) 
    end 
    it 'has not enough money in account' do
        expect{@account1.withdraw(1000, "checking")}.to raise_error(ArgumentError)
    end
    it 'attempts to check the number of accounts' do
        expect{BankAccount.no_of_accounts}.to raise_error(NoMethodError)
    end
    it 'attempts to change the interest rate' do
        expect{@account1.interest_rate = 0.5}.to raise_error(NoMethodError)
    end
end