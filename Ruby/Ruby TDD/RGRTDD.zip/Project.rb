class Project
    def initialize(name="Project", description="Description", owner = "owner", tasks = []) 
        @project_name = name 
        @description = description 
        @owner = owner
        @tasks = tasks
        puts "Created project #{@project_name}"
      end
    def name 
      @project_name
    end
    def name= (project_name)
      @project_name = project_name
    end
    def tasks
      @tasks
    end
    def add_tasks(task)
      @tasks.push(task)
    end
    def description
      @description
    end
    def description= (description)
      @description = description
    end
    def elevator_pitch
        @pitch = @project_name +  ", " + @description
    end
end
  # project1 = Project.new("Project 1", "Description 1")
  # puts project1.name # => "Project 1"
  # puts project1.elevator_pitch  # => "Project 1, Description 1"