class SessionsController < ApplicationController
  def new
  end
  def create
    u = User.find_by(email: params[:Email])
    if u && u.authenticate(params[:Password])
      session[:user_id] = u.id
      redirect_to '/users/' + u.id.to_s
    else
      flash[:messages] = ['Invalid Combination']
      redirect_to '/sessions/new'
    end
  end
  def destroy
    session[:user_id] = nil
    redirect_to '/sessions/new'
  end
end
