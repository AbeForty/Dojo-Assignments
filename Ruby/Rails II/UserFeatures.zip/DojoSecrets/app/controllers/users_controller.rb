class UsersController < ApplicationController
  def index
  end
  def new
  end
  def create
    u = User.new(name: params[:Name], email: params[:Email], password: params[:Password], password_confirmation: params[:Password_Confirmation])
    if u.valid?
      u.save
      flash[:messages] = ['Success!']
      redirect_to '/sessions/new'
    else
      flash[:messages] = [u.errors.full_messages]
      redirect_to '/users/new'
    end
    # redirect_to '/'
  end
  def show
    @user = User.find_by(id: session[:user_id])
    # redirect_to '/users/' + @user.id.to_s
  end

  def edit
  end
end
