FactoryGirl.define do
  factory :secret do
    content "Basic Principles: There are none"
    user nil
  end
end
