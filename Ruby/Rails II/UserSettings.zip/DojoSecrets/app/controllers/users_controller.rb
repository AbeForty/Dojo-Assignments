class UsersController < ApplicationController
  def index
  end
  def new
  end
  def create
    u = User.new(name: params[:Name], email: params[:Email], password: params[:Password], password_confirmation: params[:Password_Confirmation])
    if u.valid?
      u.save
      flash[:messages] = ['Success!']
      redirect_to '/sessions/new'
    else
      flash[:messages] = [u.errors.full_messages]
      redirect_to '/users/new'
    end
    # redirect_to '/'
  end
  def show
    @user = User.find_by(id: session[:user_id])
    render 'show'
  end

  def edit
    @user = User.find_by(id: session[:user_id])
    render 'edit'
  end
  def update
    u = User.update(params[:id], name: params[:Name], email: params[:Email])
    if u.valid?
      u.save
      flash[:messages] = ['Success!']
      redirect_to '/users/' + u.id.to_s
    else
      flash[:messages] = [u.errors.full_messages]
      redirect_to '/users/' + u.id.to_s + '/edit'
    end
  end
  def destroy
    u = User.find(params[:id])
    u.delete
    session.clear
    redirect_to '/users/new'
  end
end
