class Mammal
    def initialize()
        @health = 150
    end
    def health
        @health
    end
    def health= (value)
        @health = value
    end
    def display_health
        puts @health
        puts "I love... Squirrel!"
    end
end