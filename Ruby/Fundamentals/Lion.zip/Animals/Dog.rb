require_relative 'Mammal'
class Dog < Mammal
    def pet
        @health = @health + 5
        self
    end
    def walk
        # puts "Health: "
        # puts health
        @health = @health - 1
        # puts "Hello"
        self
    end
    def run
        @health = @health - 10
        # puts "Hello"
        self
    end
end
einstein = Dog.new
einstein.walk.walk.walk.run.run.pet.display_health