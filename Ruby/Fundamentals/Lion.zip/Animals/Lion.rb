require_relative 'Mammal'
class Lion < Mammal
    def initialize
        @health = 170
    end
    def fly
        # puts "Health: "
        # puts health
        @health = @health - 10
        # puts "Hello"
        self
    end
    def attack_town
        @health = @health - 50
        # puts "Hello"
        self
    end
    def eat_humans
        @health = @health + 20
        # puts "Hello"
        self
    end
end
Aslan = Lion.new
Aslan.attack_town.attack_town.attack_town.eat_humans.eat_humans.fly.fly.display_health