require_relative 'Human'
class Ninja
  def initialize
    @stealth = 175
  end
  def steal(obj)
    if obj.class.ancestors.include?(Human)
        attack(obj)
        @health += 10
        true
      else
        false
      end
  end
  def get_away(object)  
    @health -= 15   
  end
end