require_relative 'Human'
class Samurai
  @@number_of_samurai = 0
  def initialize
    @health = 200
    @@number_of_samurai += 1
  end
  def death_blow(obj)
    if obj.class.ancestors.include?(Human)
        attack(obj)
        obj.health = 10
        true
      else
        false
      end
  end
  def meditate(object)  
    @health = 200
  end
  def how_many(object)  
    @@number_of_samurai 
  end
end