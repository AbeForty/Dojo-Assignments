require_relative 'Human'
class Wizard
  def initialize
    @intelligence = 25
    @health = 50
  end
  def heal
    @health += 10
  end
  def fireball(obj)
    if obj.class.ancestors.include?(Human)
        attack(obj)
        obj.health -= 20
        true
      else
        false
      end
  end
end