class UsersController < ApplicationController
  def new
  end
  def create
    @user = User.new(params.require(:user).permit(:first_name, :last_name, :email))
    if @user.save
      flash[:notice] = ['User successfully created']
      flash[:notice] = [('Welcome, ' + @user.first_name)]
      return redirect_to user_path(@user)
    else
      flash[:notice] = @user.errors.full_messages
      return redirect_to '/users/new'
      #errors we need to code later
    end
  end
#   def show
#     render 'show'
#   end
end
